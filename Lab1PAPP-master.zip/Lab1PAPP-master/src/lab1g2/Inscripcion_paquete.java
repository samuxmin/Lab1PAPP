
package lab1g2;

public class Inscripcion_paquete {
    private float costoPaquete;
    //private DataFecha fechaCompra;
    private int cantidad;
    //private DataFecha vencimiento;
    
    public Inscripcion_paquete(float costoPaquete,int cantidad){
        this.costoPaquete=costoPaquete;
        this.cantidad=cantidad;
    }
}
