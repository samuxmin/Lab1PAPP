
package lab1g2;

public class Inscripcion_general {
    //private DataFecha fechaCompra;
    private float costoGeneral;
    private int cantidad;
   
    public Inscripcion_general(int cantidad,float costoGeneral){
        this.cantidad=cantidad;
        this.costoGeneral=costoGeneral;
    }
}
