
package lab1g2;

public class Paquete {
    
    private String nombre_paquete;
    private String desc;
    //private DataFecha validez;
    private int descuento;
    public Paquete(String nombre_paquete, String desc, int descuento){
    this.nombre_paquete=nombre_paquete;
    this.desc=desc;
    this.descuento=descuento;
    }
}
