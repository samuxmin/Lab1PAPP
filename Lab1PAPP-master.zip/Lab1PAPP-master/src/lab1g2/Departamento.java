
package lab1g2;

public class Departamento {
    private String nombreDepartamento;
    
    public Departamento(String nombreDepartamento){this.nombreDepartamento=nombreDepartamento;}
    
    public String getNombreDepto(){
    return nombreDepartamento;
    }
    
}
